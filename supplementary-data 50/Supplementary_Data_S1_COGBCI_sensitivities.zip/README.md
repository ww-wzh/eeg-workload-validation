# COG-BCI response-order and eligibility sensitivities

This supplement contains the saved-prediction analyses supporting the added
cadence-only row in Table S27 and Tables S39-S41. These are post-hoc analyses.
The original BH2 and BH12 comparison families remain unchanged. The eight
response-order contrasts form a separate exploratory BH8 family.

## Contents

- results/: participant scores, recording probabilities, response changes,
  eligibility summaries, prediction errors, inference, and verification.
- inputs/gate_run/: the original aggregate analysis inputs and 6,500 saved
  prediction files used in this sensitivity. Each file is checked against
  its original model-job receipt; unrelated fitting-stage payloads referenced
  by the receipts are not included or required for this saved-prediction run.
- inputs/session_run/fold_scores.csv: fixed-learner session-pair scores.
- analyze_response_order.py: executable analysis, including source exclusions,
  original-result replay checks, gate refitting, and participant statistics.
- MANIFEST.sha256: SHA-256 checksums of the packaged files.

## Reproduce

Use Python 3.12 with NumPy 2.4.4, pandas 3.0.2, SciPy 1.17.1,
scikit-learn 1.8.0, and threadpoolctl 3.6.0. From this directory run:

    python analyze_response_order.py --gate-run inputs/gate_run --session-run inputs/session_run --out reproduced_results

The script reads saved predictions and refits only CB-SF gates. It does not
train EEG classifiers, change DASF, or use outer-target labels in gate fitting.
Diagnostics are held at their original values to isolate the response change.
There are 25 independent participants per task. The 600 response rows per
task and response source contain repeated participants across outer folds.

Original responses are medians of five seed-specific recording BA gains.
Alternative responses first take normalized componentwise medians of the
five per-window branch probabilities, then geometrically aggregate within
each recording and calculate the fused-minus-neural recording BA gain.
Loss-event labels use gain <= -0.05. Final outer predictions use the same
window-median ensemble in both comparisons. The event scores are uncalibrated.

Gate bootstrap intervals use 10,000 participant draws with seed 20261121.
All reported new paired tests use exact two-sided participant sign flips;
zero differences are omitted from enumeration. The script also implements
a 100,000-draw fallback when more than 20 differences are nonzero.
Session-eligibility intervals retain the original seed 20261110 and 10,000
participant draws. Intervals are conditional on the saved model predictions.

The package contains experimental code and derived predictions/results.
Original EEG files and model-training checkpoints are not redistributed.
