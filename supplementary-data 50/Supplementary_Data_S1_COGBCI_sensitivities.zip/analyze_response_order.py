"""Post-hoc COG-BCI response-order and session-eligibility sensitivities.

Uses saved predictions only. Base learners, diagnostics, DASF, the original
BH12 family, and source artifacts remain unchanged. All output is separate.
"""
from pathlib import Path
import argparse
import hashlib
import json
import platform
import itertools
import numpy as np
import pandas as pd
import scipy
from scipy.special import expit
import sklearn
from sklearn.linear_model import Ridge, LogisticRegression
from threadpoolctl import threadpool_limits

FEATURES = ['feature_shift', 'disagreement', 'entropy_nn', 'entropy_fuse', 'confidence_nn']
SEED = 20261121


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def dump(p, obj):
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False), encoding='utf-8')


def norm(p):
    p = np.asarray(p, dtype=np.float64)
    assert np.isfinite(p).all() and (p >= 0).all() and (p.sum(1) > 0).all()
    return p / p.sum(1, keepdims=True)


def score(p, records, labels):
    ids = np.unique(records)
    rp = norm(np.array([np.exp(np.log(np.clip(p[records == k], 1e-12, 1)).mean(0)) for k in ids]))
    y = np.array([labels[k] for k in ids])
    assert (y == 0).sum() == (y == 1).sum()
    pred = rp.argmax(1)
    ba = .5 * ((pred[y == 0] == 0).mean() + (pred[y == 1] == 1).mean())
    return float(ba), ids, rp, y


def fit_gate(rows, target):
    x = rows[FEATURES].to_numpy(dtype=np.float64)
    gains = rows.benefit.to_numpy(dtype=np.float64)
    t = np.array([[target[k] for k in FEATURES]])
    assert rows.meta_subject.nunique() == len(rows) == 24
    assert np.isfinite(x).all() and np.isfinite(gains).all() and np.isfinite(t).all()
    event = (gains <= -.05).astype(np.int64)
    center = np.median(x, axis=0)
    q1, q3 = np.quantile(x, [.25, .75], axis=0)
    scale = np.where(q3-q1 >= 1e-8, q3-q1, x.std(axis=0, ddof=0))
    scale = np.where(scale >= 1e-8, scale, 1.)
    tz = (t-center)/scale
    max_z = float(np.abs(tz).max())
    xz, tz = np.clip((x-center)/scale, -5, 5), np.clip(tz, -5, 5)
    with threadpool_limits(limits=1):
        bm = Ridge(alpha=1.).fit(xz, gains)
        raw = float(bm.predict(tz)[0])
        benefit = float(np.clip(raw, max(-1., gains.min()), min(1., gains.max())))
        if len(np.unique(event)) == 2:
            em = LogisticRegression(C=1., class_weight='balanced', max_iter=2000, random_state=0).fit(xz, event)
            assert np.all(em.n_iter_ < 2000)
            ev = float(em.predict_proba(tz)[0, 1])
        else:
            ev = float(event.mean())
    weight = 0. if max_z > 10. else .8 * expit(np.clip((benefit-.05*ev)/.02, -40., 40.))
    return dict(weight=float(weight), predicted_benefit=benefit, predicted_event_score=ev,
                training_mean_benefit=float(gains.mean()), training_mean_event=float(event.mean()),
                loss_events=int(event.sum()), constant_event_fallback=bool(len(np.unique(event)) == 1),
                ood_fallback=bool(max_z > 10), max_abs_robust_z=max_z)


def ci(v, draws):
    return tuple(float(x) for x in np.quantile(np.asarray(v)[draws].mean(1), [.025, .975]))


def signflip(d):
    d = np.asarray(d)
    d = d[np.abs(d) > 1e-12]
    if len(d) == 0:
        return 1., 'exact', 1
    if len(d) <= 20:
        signs = np.array(list(itertools.product([-1, 1], repeat=len(d))), dtype=np.int8)
        p = float((np.abs(signs @ d) >= abs(d.sum())-1e-12).mean())
        return p, 'exact', len(signs)
    rng = np.random.default_rng(SEED)
    signs = rng.choice([-1, 1], (100000, len(d)))
    return float((1+(np.abs(signs @ d) >= abs(d.sum())-1e-12).sum())/100001), 'monte_carlo', 100000


def main(args):
    run, session, out = args.gate_run.resolve(), args.session_run.resolve(), args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    inputs = {}
    receipts = {}
    verified = set()
    def csv(path):
        inputs[path.relative_to(path.parents[1]).as_posix()] = sha(path)
        return pd.read_csv(path, float_precision='round_trip')
    meta = csv(run/'analysis/meta_rows.csv')
    seed_meta = csv(run/'analysis/meta_seed_rows.csv').set_index(['task','outer_subject','meta_subject','kind','seed'])
    oldg = csv(run/'analysis/gate_diagnostics.csv')
    oldg = oldg[oldg['mode'] == 'ensemble'].set_index(['task','subject','method'])
    olds = csv(run/'analysis/participant_scores.csv')
    olds = olds[olds['mode'] == 'ensemble'].set_index(['task','subject','method'])
    oldr = csv(run/'analysis/record_scores.csv')
    oldr = oldr[oldr['mode'] == 'ensemble']
    labels = oldr[['record_id','label']].drop_duplicates()
    assert labels.record_id.is_unique
    labels = labels.set_index('record_id').label.to_dict()
    subjects = sorted(meta.outer_subject.unique().tolist())
    seeds = sorted(seed_meta.index.get_level_values('seed').unique().tolist())
    assert len(subjects) == 25 and len(seeds) == 5
    dump(out/'analysis_design.json', dict(status='post_hoc_descriptive_sensitivity',
        subjects=subjects, seeds=seeds, response='BA of five-seed window-median fused branch minus BA of five-seed window-median neural branch',
        diagnostics='Retain saved median-of-seed diagnostics and original target diagnostics.',
        fixed='Base predictions, participant exclusions, transforms, gate constants, DASF, original BH2 and BH12 results.',
        comparisons=['ensemble heldout - seed-summary heldout','ensemble heldout - Feature-MLP','ensemble heldout - always-fuse','ensemble heldout - ensemble proxy'],
        statistics='10000 participant bootstrap draws; paired exact sign flips for <=20 nonzero differences, otherwise 100000 Monte Carlo draws; separate exploratory BH8 family.',
        bootstrap_seed=SEED, code_sha256=sha(Path(__file__))))

    def get(task, excluded, seed, target=None):
        exc = sorted(excluded)
        jid = f'{task}_outer_s{exc[0]:02d}_seed{seed}' if len(exc)==1 else f'{task}_exclude_s{exc[0]:02d}_s{exc[1]:02d}_seed{seed}'
        base = run/'jobs'/jid
        if jid not in receipts:
            receipt = json.loads((base/'complete.json').read_text(encoding='utf-8'))
            j = receipt['identity']['job']
            assert j['excluded_subjects'] == exc and j['seed'] == seed and j['task'] == task
            assert set(j['training_subjects']) == set(subjects)-set(exc)
            receipts[jid] = receipt
        name = 'oof_predictions.npz' if target is None else f'target_s{target:02d}_predictions.npz'
        p = base/name
        if (jid,name) not in verified:
            expected = receipts[jid]['files_sha256'][name]
            assert sha(p) == expected, str(p)
            verified.add((jid,name))
        with np.load(p, allow_pickle=False) as a:
            return {k:a[k] for k in ['window_ids','record_ids','feature_mlp','always_fuse'] + (['subject'] if target is None else [])}

    results, responses, rec_results = [], [], []
    max_replay_error = 0.
    for task in ['NBACK','MATB']:
        for outer in subjects:
            outer_arrays = [get(task,[outer],s,outer) for s in seeds]
            proxies = [get(task,[outer],s) for s in seeds]
            for a in outer_arrays[1:]:
                assert np.array_equal(a['window_ids'], outer_arrays[0]['window_ids'])
                assert np.array_equal(a['record_ids'], outer_arrays[0]['record_ids'])
            records = outer_arrays[0]['record_ids']
            nn = norm(np.median([a['feature_mlp'] for a in outer_arrays],axis=0))
            ff = norm(np.median([a['always_fuse'] for a in outer_arrays],axis=0))
            nba = score(nn,records,labels)[0]; fba = score(ff,records,labels)[0]
            assert abs(nba-olds.loc[(task,outer,'feature_mlp'),'balanced_accuracy']) < 1e-12
            assert abs(fba-olds.loc[(task,outer,'always_fuse'),'balanced_accuracy']) < 1e-12
            new_by_kind = {'proxy':{},'heldout':{}}
            for m in subjects:
                if m == outer: continue
                held = [get(task,[outer,m],s,m) for s in seeds]
                for kind in ['proxy','heldout']:
                    arr = held if kind=='heldout' else [{k:a[k][a['subject']==m] for k in ['window_ids','record_ids','feature_mlp','always_fuse']} for a in proxies]
                    for a in arr:
                        assert np.array_equal(a['window_ids'], held[0]['window_ids'])
                        assert np.array_equal(a['record_ids'], held[0]['record_ids'])
                    for seed,a in zip(seeds,arr):
                        ns=score(a['feature_mlp'],a['record_ids'],labels)[0]
                        fs=score(a['always_fuse'],a['record_ids'],labels)[0]
                        old=seed_meta.loc[(task,outer,m,kind,seed)]
                        assert abs(ns-old.neural_ba)<1e-12 and abs(fs-old.fused_ba)<1e-12
                        assert abs(fs-ns-old.benefit)<1e-12
                    pn=norm(np.median([a['feature_mlp'] for a in arr],axis=0))
                    pf=norm(np.median([a['always_fuse'] for a in arr],axis=0))
                    gain=score(pf,arr[0]['record_ids'],labels)[0]-score(pn,arr[0]['record_ids'],labels)[0]
                    new_by_kind[kind][m]=gain
            for kind in ['proxy','heldout']:
                method='cbsf_'+kind
                train=meta[(meta.task==task)&(meta.outer_subject==outer)&(meta.kind==kind)].sort_values('meta_subject').copy()
                target=oldg.loc[(task,outer,method),FEATURES].to_dict()
                orig=fit_gate(train,target)
                old=oldg.loc[(task,outer,method)]
                for key in ['weight','predicted_benefit','predicted_event_score']:
                    err=abs(orig[key]-old[key]);max_replay_error=max(max_replay_error,err)
                    assert err<1e-10,(task,outer,kind,key,err)
                changed=train.copy();changed['benefit']=changed.meta_subject.map(new_by_kind[kind])
                assert np.array_equal(changed[FEATURES],train[FEATURES])
                for a,b in zip(train.itertuples(),changed.itertuples()):
                    responses.append(dict(task=task,outer_subject=outer,meta_subject=a.meta_subject,kind=kind,
                        original_gain=a.benefit,ensemble_gain=b.benefit,gain_changed=abs(a.benefit-b.benefit)>1e-12,
                        original_event=bool(a.benefit<=-.05),ensemble_event=bool(b.benefit<=-.05)))
                for order, gate in [('seed_summary',orig),('ensemble_response',fit_gate(changed,target))]:
                    ba,ids,rp,y=score(norm((1-gate['weight'])*nn+gate['weight']*ff),records,labels)
                    if order=='seed_summary':
                        assert abs(ba-olds.loc[(task,outer,method),'balanced_accuracy'])<1e-12
                        saved=oldr[(oldr.task==task)&(oldr.subject==outer)&(oldr.method==method)].set_index('record_id').loc[ids]
                        assert np.max(abs(saved.p1.to_numpy()-rp[:,1]))<1e-10
                    realized=fba-nba; event=int(realized<=-.05)
                    results.append(dict(task=task,subject=outer,kind=kind,order=order,ba=ba,neural_ba=nba,fused_ba=fba,
                        realized_gain=realized,realized_loss_event=event,**gate,
                        event_squared_error=(gate['predicted_event_score']-event)**2,
                        baseline_event_squared_error=(gate['training_mean_event']-event)**2,
                        benefit_squared_error=(gate['predicted_benefit']-realized)**2,
                        baseline_benefit_squared_error=(gate['training_mean_benefit']-realized)**2))
                    rec_results.extend(dict(task=task,subject=outer,kind=kind,order=order,record_id=k,label=int(v),p0=float(p[0]),p1=float(p[1]),prediction=int(p.argmax())) for k,v,p in zip(ids,y,rp))
            print(f'Checked predictions and refitted gates: {task} {outer:02d}',flush=True)
    frames={'response_rows':pd.DataFrame(responses),'participant_scores':pd.DataFrame(results),'record_predictions':pd.DataFrame(rec_results)}
    p=frames['participant_scores']; resp=frames['response_rows']; rec=frames['record_predictions']
    draws=np.random.default_rng(SEED).integers(0,25,(10000,25))
    summaries=[]; errors=[]; contrasts=[]
    for task in ['NBACK','MATB']:
        for kind in ['proxy','heldout']:
            a=p[(p.task==task)&(p.kind==kind)&(p.order=='seed_summary')].set_index('subject').loc[subjects]
            b=p[(p.task==task)&(p.kind==kind)&(p.order=='ensemble_response')].set_index('subject').loc[subjects]
            rr=resp[(resp.task==task)&(resp.kind==kind)]
            decisions=rec[(rec.task==task)&(rec.kind==kind)].pivot(index=['subject','record_id'],columns='order',values='prediction')
            flips=decisions.seed_summary!=decisions.ensemble_response
            delta=(b.ba-a.ba).to_numpy();lo,hi=ci(delta,draws)
            summaries.append(dict(task=task,kind=kind,n=25,response_rows=len(rr),changed_gain_rows=int(rr.gain_changed.sum()),
                changed_event_rows=int((rr.original_event!=rr.ensemble_event).sum()),original_events=int(rr.original_event.sum()),ensemble_events=int(rr.ensemble_event.sum()),
                changed_weights=int((abs(a.weight-b.weight)>1e-12).sum()),changed_class_decisions=int(flips.sum()),n_records=len(decisions),
                participants_with_changed_decisions=int(flips.groupby(level=0).any().sum()),original_ba=float(a.ba.mean()),ensemble_ba=float(b.ba.mean()),
                original_ci_low=ci(a.ba,draws)[0],original_ci_high=ci(a.ba,draws)[1],ensemble_ci_low=ci(b.ba,draws)[0],ensemble_ci_high=ci(b.ba,draws)[1],
                difference=float(delta.mean()),ci_low=lo,ci_high=hi,better=int((delta>1e-12).sum()),tied=int((abs(delta)<=1e-12).sum()),worse=int((delta< -1e-12).sum())))
            for order,z in [('seed_summary',a),('ensemble_response',b)]:
                errors.append(dict(task=task,kind=kind,order=order,event_mse=float(z.event_squared_error.mean()),baseline_event_mse=float(z.baseline_event_squared_error.mean()),
                    benefit_rmse=float(np.sqrt(z.benefit_squared_error.mean())),baseline_benefit_rmse=float(np.sqrt(z.baseline_benefit_squared_error.mean())),
                    outer_loss_events=int(z.realized_loss_event.sum()),constant_fallbacks=int(z.constant_event_fallback.sum()),ood_fallbacks=int(z.ood_fallback.sum())))
        z=p[(p.task==task)&(p.kind=='heldout')]
        b=z[z.order=='ensemble_response'].set_index('subject').loc[subjects]
        original=z[z.order=='seed_summary'].set_index('subject').loc[subjects]
        proxy=p[(p.task==task)&(p.kind=='proxy')&(p.order=='ensemble_response')].set_index('subject').loc[subjects]
        for name,other in [('seed_summary_heldout',original.ba),('feature_mlp',b.neural_ba),('always_fuse',b.fused_ba),('ensemble_proxy',proxy.ba)]:
            d=(b.ba-other).to_numpy();lo,hi=ci(d,draws);pv,test,nd=signflip(d)
            contrasts.append(dict(task=task,contrast='ensemble_heldout - '+name,n=25,difference=float(d.mean()),ci_low=lo,ci_high=hi,
                better=int((d>1e-12).sum()),tied=int((abs(d)<=1e-12).sum()),worse=int((d< -1e-12).sum()),p=pv,test=test,draws=nd))
    ps=np.array([r['p'] for r in contrasts]);order=np.argsort(ps)
    qs=np.minimum(1,np.minimum.accumulate((ps[order]*len(ps)/np.arange(1,len(ps)+1))[::-1])[::-1])
    for i,q in zip(order,qs):contrasts[i]['q_BH8']=float(q)
    frames.update(response_order_summary=pd.DataFrame(summaries),prediction_errors=pd.DataFrame(errors),exploratory_contrasts_BH8=pd.DataFrame(contrasts))
    folds=csv(session/'fold_scores.csv')
    session_rows=[];session_part=[]
    for name,mask in [('primary',folds.primary),('restore_interrupted',folds.matching_cadence),('relax_cadence_only',folds.uninterrupted),('relax_both',np.ones(len(folds),bool))]:
        f=folds[(folds.task=='NBACK')&mask]
        assert f.groupby(['pair_id','arm']).size().eq(5).all()
        part=f.groupby(['subject','arm']).record_ba.mean().unstack().loc[subjects]
        a,b=part.same_record.to_numpy(),part.cross_session.to_numpy();d=a-b
        draw=np.random.default_rng(20261110).integers(25,size=(10000,25))
        session_rows.append(dict(population=name,n=25,pairs=int(f.pair_id.nunique()),cells=int(f[['subject','target']].drop_duplicates().shape[0]),
            same_ba=float(a.mean()),same_ci_low=ci(a,draw)[0],same_ci_high=ci(a,draw)[1],cross_ba=float(b.mean()),cross_ci_low=ci(b,draw)[0],cross_ci_high=ci(b,draw)[1],
            difference=float(d.mean()),ci_low=ci(d,draw)[0],ci_high=ci(d,draw)[1],positive=int((d>1e-12).sum())))
        session_part.extend(dict(population=name,subject=s,same_ba=float(x),cross_ba=float(y),difference=float(x-y)) for s,x,y in zip(subjects,a,b))
    frames['session_eligibility_summary']=pd.DataFrame(session_rows)
    frames['session_participant_scores']=pd.DataFrame(session_part)
    for name,frame in frames.items():frame.to_csv(out/(name+'.csv'),index=False,float_format='%.17g')
    dump(out/'verification.json',dict(status='passed',verified_prediction_files=len(verified),verified_model_jobs=len(receipts),replayed_original_gates=100,
        max_original_gate_replay_error=max_replay_error,seed_response_checks=12000,meta_response_rows=2400,participants_per_task=25,
        runtime=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__),inputs=inputs))
    print(json.dumps(summaries,indent=2))
    print(frames['session_eligibility_summary'].to_string(index=False))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--gate-run',type=Path,required=True)
    parser.add_argument('--session-run',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    main(parser.parse_args())
